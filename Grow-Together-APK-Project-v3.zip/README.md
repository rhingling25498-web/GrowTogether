# Grow Together - Student AI Assistant

ကျောင်းသားများအတွက် PDF စာအုပ်/စာတမ်းများကို အခြေခံပြီး Assignment ရေးသားခြင်း (Citations & References ပါဝင်) နှင့် မြန်မာဘာသာပြန်ခြင်းတို့ကို လုပ်ဆောင်ပေးမည့် Android App Project ဖြစ်ပါသည်။
