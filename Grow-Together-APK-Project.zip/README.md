# Grow Together - Student AI Assistant

ကျောင်းသားများအတွက် PDF စာအုပ်/စာတမ်းများကို အခြေခံပြီး Assignment ရေးသားခြင်း (Citations & References ပါဝင်) နှင့် မြန်မာဘာသာပြန်ခြင်းတို့ကို လုပ်ဆောင်ပေးမည့် Android App Project ဖြစ်ပါသည်။

## APK ထုတ်ယူနည်း (GitHub Actions)
1. ဤ Project ဖိုင်များကို GitHub Repository အသစ်တစ်ခုထဲသို့ Upload တင်ပါ။
2. GitHub ပေါ်ရှိ **Actions** Tab သို့ ဝင်ပါ။
3. **Build Grow Together APK** workflow ကို နှိပ်ပြီး **Run workflow** ကို နှိပ်ပါ (သို့မဟုတ် code တင်လိုက်သည်နှင့် အလိုအလျောက် စတင်ပါမည်)။
4. Build ပြီးဆုံးသွားပါက **Artifacts** အောက်ရှိ **Grow-Together-APK** ကို Download ဆွဲပြီး ဖုန်းတွင် Install လုပ်နိုင်ပါပြီ။

## အသုံးပြုပုံ
- **Settings (API Key):** App ၏ အပေါ်ညာဘက်ရှိ Settings ခလုတ်ကို နှိပ်ပြီး Gemini API Key ထည့်သွင်းပါ (API Key မရှိသေးပါက Offline Demo Mode ဖြင့် စမ်းသပ်အသုံးပြုနိုင်ပါသည်)။
- **PDF Upload:** စာအုပ် သို့မဟုတ် မှတ်စု PDF ဖိုင်ကို ရွေးချယ်တင်ပါ။
- **Assignment ရေးရန် / မြန်မာဘာသာပြန်ရန်:** သက်ဆိုင်ရာ ခလုတ်ကို နှိပ်လိုက်သည်နှင့် သက်ဆိုင်ရာ လုပ်ဆောင်ချက် UI များ ပေါ်လာပါမည်။
