# Grow Together - Student AI Assistant

Modern, clean, student-friendly Android AI study assistant for PDF-based assignment drafting (with citations & references), Myanmar translation, and easy export.
