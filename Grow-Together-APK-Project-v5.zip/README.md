# Grow Together - Student AI Assistant

PDF စာအုပ်များကို ရွေးချယ်တင်သွင်းခြင်း၊ Assignment ရေးသားခြင်း (Citations & References ပါဝင်)၊ မြန်မာဘာသာပြန်ခြင်း နှင့် Word (.docx) / PDF (.pdf) Export လုပ်ခြင်းတို့ အလုပ်လုပ်သော Android App Project ဖြစ်ပါသည်။
